--This SQL executes a number of temp tables in succesion and produces a final table in whcih data will be
--passed to the mail merge process for modeling.
--NOTE THIS CODE SUBS PDM_CLAIMS table for all instances of PAC_STORE_PDM
--region pull curent inpatient lists
DROP TABLE IF EXISTS patient_list;
CREATE LOCAL TEMPORARY TABLE patient_list ON COMMIT PRESERVE ROWS AS
select
qry2.NPI_FACILITY_NAME
,qry1.*
,qry2.COMMON_NPI
,current_date() - qry1.CURRENT_FACILITY_ADMIT_DATE as CURRENT_LOS
,qry3.*

from
  (
  select
  *
  from MEDECON_PRD.CARE_COORDINATION_TABLEAU_QUERY a
  where 
  a.EVENTRANK = 1 --might exclude duplicates
  and a.CURRENT_FACILITY_TYPE_CODE_BY_NPI = 'HOS' --from Scott but may not need due to NPI filtering
  --Filter for non overlap markets data
  --AND ((PAYER_NAME ILIKE '%WELLCARE%' AND PATIENT_STATE ILIKE 'ME') OR (PAYER_NAME ILIKE '%AMBETTER%' AND PATIENT_STATE IN('MO','NE', 'NV', 'NM', 'OH', 'OK', 'PA')) OR (PAYER_NAME ILIKE '%HORIZON%'))
  --AND ((PAYER_NAME ILIKE '%WELLCARE%' AND PATIENT_STATE IN('CT', 'GA', 'KY', 'LA', 'FL', 'NY', 'TN', 'ME')) OR (PAYER_NAME ILIKE '%AMBETTER%' AND PATIENT_STATE IN('IN', 'NH', 'PA','MS','SC','WA')) OR (PAYER_NAME ILIKE '%HORIZON%') OR (PAYER_NAME ILIKE '%OPTIMA%'))
  --AND (PAYER_NAME ILIKE '%WELLCARE%' OR PAYER_NAME ILIKE '%HORIZON%' OR PAYER_NAME ILIKE '%AMBETTER%' OR PAYER_NAME ILIKE '%OPTIMA%') 
  ) as qry1
  
left join 
  (
  select
  a.UNIQUE_NPI
  ,a.COMMON_NPI
  ,a.NPI_FACILITY_NAME
  from MEDECON_PRD.NPI_CONSOLIDATION a
  ) as qry2
  on qry1.CURRENT_FACILITY_NPI = qry2.UNIQUE_NPI
  
left join
  (
  select
  a.CARE_COORD_PROG_EVENT_ID as CARE_COORD_PROG_EVENT_ID_enr
  ,a.PROG_PTHWY_DESC
  from EIW_PRD.CARE_COORDINATION_PROGRAM_ENROLLMENT a
  where
  a.PROG_PTHWY_DESC = 'Inpatient: Acute'
  ) as qry3
  on qry1.CARE_COORD_PROG_EVENT_ID = qry3.CARE_COORD_PROG_EVENT_ID_enr
where 
qry2.COMMON_NPI is not null
and qry3.PROG_PTHWY_DESC is not null
;
-- drop table patient_list;
--select * from patient_list;
--end region

--region DX Temp Table - Brings in DX Risks
DROP TABLE IF EXISTS DX_Risk;
CREATE LOCAL TEMPORARY TABLE DX_Risk ON COMMIT PRESERVE ROWS AS

select
coalesce(qry1.CLIENT,qry2.CLIENT,qry3.CLIENT) as CLIENT
,coalesce(qry1.dx,qry2.dx,qry3.DX) as DX
,Adj_DX_1_RR
,Adj_DX_2_RR
,Adj_DX_3_RR

from
(
select 
a.CLIENT,
a.DX1 as DX
,(sum(EPI_IS_READMIT_90_DAY)+0.2641)/(count(a.DX1)+1) as Adj_DX_1_RR
from MEDECON_PRD.PDM_CLAIMS a
where
--a.CLIENT ILIKE 'WELLCARE' --Wellcare
--and 
a.POS = '21' --Inpatient stays only
group by 1,2
) as qry1

FULL OUTER JOIN

(
select 
a.CLIENT,
a.DX2 as DX
,(sum(EPI_IS_READMIT_90_DAY)+0.2641)/(count(a.DX2)+1) as Adj_DX_2_RR
from MEDECON_PRD.PDM_CLAIMS a
where
--a.CLIENT ILIKE 'WELLCARE'  --Wellcare
--and 
a.POS = '21' --Inpatient stays only
group by 1,2
--limit(10)
) as qry2 on (qry1.DX = qry2.DX AND qry1.CLIENT = qry2.CLIENT)

Full Outer Join

(
select 
a.CLIENT,
a.DX3 as DX
,(sum(EPI_IS_READMIT_90_DAY)+0.2641)/(count(a.DX3)+1) as Adj_DX_3_RR
from MEDECON_PRD.PDM_CLAIMS a
where
--a.CLIENT ILIKE 'WELLCARE'  --Wellcare
--and 
a.POS = '21' --Inpatient stays only
group by 1,2
) as qry3 on (ISNULL(qry1.DX, qry2.DX) = qry3.DX AND ISNULL(qry1.CLIENT, qry2.CLIENT)= qry3.CLIENT)
;

--drop table DX_Risk;
--end region

--region PAC Temp Table PART 1 - Brings in Stays from Claims Data
DROP TABLE IF EXISTS PAC_1;
CREATE LOCAL TEMPORARY TABLE PAC_1 ON COMMIT PRESERVE ROWS AS
select
a.MEMBER_ID
,a.PAC_STY_ID
,a.STAY_ADMIT_DATE
,a.STAY_DISCHARGE_DATE
,a.DX1
,a.DX2
,a.DX3

from MEDECON_PRD.PDM_CLAIMS a
inner join ( select distinct a.PATIENT_MEMBER_ID from patient_list a) b on a.MEMBER_ID = b.PATIENT_MEMBER_ID
where
--a.CLIENT ILIKE 'WELLCARE' --Wellcare
a.POS = '21' --Inpatient stays only
--and a.member_id in ('20220981','21068581','10432302','26789176') --Sample Patients

UNION ALL

select 
distinct
a.PATIENT_MEMBER_ID as MEMBER_ID
,row_number() over(partition by null order by a.PATIENT_MEMBER_ID) + b.max_pac as PAC_STY_ID
,a.CURRENT_FACILITY_ADMIT_DATE as STAY_ADMIT_DATE --added to account for count 180/ count 365
,current_date() as STAY_DISCHARGE_DATE--Doesnt make sense to bring in value if patient is currently in facility
,a.DIAGNOSIS_CODE as DX1
,a.SECONDARY_DIAGNOSIS_CODE as DX2
,null as DX3

from patient_list a
cross join (select max(a.pac_sty_id) as max_pac from MEDECON_PRD.PDM_CLAIMS a) b

;

--drop table PAC_1;
--end region

--region PAC Temp Table PART 2 - Assigns currenty stay a prior stay
CREATE LOCAL TEMPORARY TABLE PAC_2 ON COMMIT PRESERVE ROWS AS
Select
qry1.*
,qry2.Stay_Admit_Date as PRIOR_STAY_ADMIT_DATE
,qry2.Stay_Admit_Date as PRIOR_STAY_DISCHARGE_DATE
from
(
select
a.*
,row_number() over(partition by null order by a.MEMBER_ID, a.PAC_STY_ID) as pac_order
from PAC_1 a
) as qry1
left join
(
select
a.*
,row_number() over(partition by null order by a.MEMBER_ID, a.PAC_STY_ID) + 1 as pac_order
from PAC_1 a
) as qry2 on qry1.MEMBER_ID = qry2.MEMBER_ID and qry1.pac_order = qry2.pac_order
;
--drop table PAC_2;
--end region

--region PAC Temp Table PART 3 - Brings in Stays
CREATE LOCAL TEMPORARY TABLE PAC_3 ON COMMIT PRESERVE ROWS AS

select
distinct
a.MEMBER_ID
,a.PAC_STY_ID
,a.STAY_ADMIT_DATE
,a.STAY_DISCHARGE_DATE
,a.PRIOR_STAY_ADMIT_DATE
,a.PRIOR_STAY_DISCHARGE_DATE
,a.DX1
,a.DX2
,a.DX3
--adD client
,case when b.member_id is null then 0 else 1 end as SNF_Hist
,case when c.total_admit_count is null then 0 else c.total_admit_count end + 1 as total_admit_count
from 
(
select
*
from PAC_2
) as a

left join (
           select distinct
           a.member_id
           --ADD CLIENT
           from MEDECON_PRD.PDM_CLAIMS a
           where
           --a.CLIENT ILIKE 'WELLCARE' and --REMOVE CLIENT
           a.POS = '21' --Inpatient stays only
           and case when a.NEXT_POS = '31' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3 then 'SNF'
               else null
               end = 'SNF'
           ) b on a.MEMBER_ID = b.MEMBER_ID--adD client to join
           
left join (
           select
           a.member_id
           ,count(distinct a.pac_sty_id) as total_admit_count
          from MEDECON_PRD.PDM_CLAIMS a
           where
           --a.CLIENT ILIKE 'WELLCARE' and ---REMOVE CLIENT
           a.POS = '21' --Inpatient stays only
           group by 1--2
           ) c on a.MEMBER_ID = c.MEMBER_ID --adD client to join

;
--drop table PAC_3;
--end region

--region PAC Temp Table PART 4 - Brings in Hopsital admits from prior 180, 365
CREATE LOCAL TEMPORARY TABLE PAC_4 ON COMMIT PRESERVE ROWS AS

select
a.*
--Previous_counts by 90, 180, 365
--,count(distinct b.PAC_STY_ID)-1 as Admits_90
--,case when count(distinct case when b.Readmit_90 = 1 then b.PAC_STY_ID else null end)-1 < 0 then 0 else count(distinct case when b.Readmit_90 = 1 then b.PAC_STY_ID else null end)-1 end as Readmits_90
,count(distinct c.PAC_STY_ID)-1 as Count_180
--,case when count(distinct case when c.Readmit_90 = 1 then c.PAC_STY_ID else null end)-1 < 0 then 0 else count(distinct case when c.Readmit_90 = 1 then c.PAC_STY_ID else null end)-1 end as Readmits_180
,count(distinct d.PAC_STY_ID)-1 as Count_365
--,case when count(distinct case when d.Readmit_90 = 1 then d.PAC_STY_ID else null end)-1 < 0 then 0 else count(distinct case when d.Readmit_90 = 1 then d.PAC_STY_ID else null end)-1 end as Readmits_365
from PAC_3 a
--left join PAC_1 b on b.MEMBER_ID = a.MEMBER_ID and b.STAY_ADMIT_DATE between a.STAY_DISCHARGE_DATE - 90 and a.STAY_DISCHARGE_DATE
left join PAC_3 c on c.MEMBER_ID = a.MEMBER_ID and c.STAY_ADMIT_DATE between a.STAY_DISCHARGE_DATE - 180 and a.STAY_DISCHARGE_DATE
left join PAC_3 d on d.MEMBER_ID = a.MEMBER_ID and d.STAY_ADMIT_DATE between a.STAY_DISCHARGE_DATE - 365 and a.STAY_DISCHARGE_DATE
group by 1,2,3,4,5,6,7,8,9,10,11
;
--drop table PAC_2;
--end region

--region PAC Temp Table PART 5 - Brings in Streak_90
CREATE LOCAL TEMPORARY TABLE PAC_5 ON COMMIT PRESERVE ROWS AS
select
qrya.*
,qryb.Streak_90


from
(
select
a.*
from PAC_4 a
) as qrya

left join

(
select
qry2.*
,(case when Streak_flag = 0 then 0
       else row_number() over (partition by member_id, grouping order by pac_sty_id) - 1
       end) as Streak_90
from
(
select
qry1.*
,sum(case when Streak_flag = 0 then 1 else 0 end) over
                 (partition by member_id
                  order by pac_sty_id
                  rows between unbounded preceding and current row
                 ) as grouping
from
(
select
a.member_id
,a.pac_sty_id
,a.stay_admit_date
,a.STAY_DISCHARGE_DATE
,a.PRIOR_STAY_ADMIT_DATE
,a.PRIOR_STAY_DISCHARGE_DATE
,a.prior_stay_discharge_date - a.stay_Admit_date as Streak_count
,case when a.prior_stay_discharge_date - a.stay_Admit_date >= -90 then 1 else 0 end as Streak_flag
from PAC_4 a

) as qry1
) as qry2
) as qryb
on qrya.pac_sty_id = qryb.pac_sty_id
;
--drop table PAC_4;
--end region

--region PAC Temp Table PART 6 - Brings in No_Streak
CREATE LOCAL TEMPORARY TABLE PAC_6 ON COMMIT PRESERVE ROWS AS

select
qry1.*
,qry2.No_Streak
from
(
select
*
from PAC_5
) as qry1
left join
(
select
a.member_id
,case when max(a.total_admit_count) = 1 then 0
      when max(a.streak_90) >= 1 then 2
      else 1
      end as No_Streak
from PAC_5 a
group by 1
) as qry2 on qry1.member_id = qry2.member_id
;
--drop table PAC_6;
--select * from PAC_6;
--end region

--region PAC Temp Table PART 7 - Brings in DX_Risks
CREATE LOCAL TEMPORARY TABLE PAC_7 ON COMMIT PRESERVE ROWS AS

select
qry1.MEMBER_ID
,qry1.PAC_STY_ID
,qry1.STAY_ADMIT_DATE
,qry1.STAY_DISCHARGE_DATE
,qry1.DX1
,qry1.DX2
,qry1.DX3
,qry2.Historical_DX1_readmission_risk
,qry2.Historical_DX2_readmission_risk
,qry2.Historical_DX3_readmission_risk
,qry1.Count_180
,qry1.Count_365
,qry1.Streak_90
,qry1.No_Streak
,qry1.SNF_Hist

from
(
select
a.*
from PAC_6 a
) as qry1

left join

(
select
a.member_id
,max(b.Adj_DX_1_RR) as Historical_DX1_readmission_risk
,max(c.Adj_DX_2_RR) as Historical_DX2_readmission_risk
,max(d.Adj_DX_3_RR) as Historical_DX3_readmission_risk
from 
(
select
a.CLIENT
,a.MEMBER_ID
,a.DX1
,a.DX2
,a.DX3
from MEDECON_PRD.PDM_CLAIMS a
inner join patient_list b on a.MEMBER_ID = b.PATIENT_MEMBER_ID
) as a
left join DX_Risk b on (a.DX1 = b.DX AND a.CLIENT=b.CLIENT)
left join DX_Risk c on (a.DX2 = c.DX AND a.CLIENT=c.CLIENT)
left join DX_Risk d on (a.DX3 = d.DX AND a.CLIENT=d.CLIENT)
group by 1
) as qry2 on qry1.member_id = qry2.member_id
order by qry1.MEMBER_ID,qry1.PAC_STY_ID
;
--drop table PAC_7;
--end region

--region Combine PAC Variables with Original Data Set - Brings in DX_Risks

DROP TABLE IF EXISTS patient_list_w_pac_variables;
CREATE LOCAL TEMPORARY TABLE patient_list_w_pac_variables ON COMMIT PRESERVE ROWS AS
select
qry1.*
,qry2.Historical_DX1_readmission_risk
,qry2.Historical_DX2_readmission_risk
,qry2.Historical_DX3_readmission_risk
,qry2.Count_180
,qry2.Count_365
,qry2.Streak_90
,qry2.No_Streak
,qry2.SNF_Hist

from

(
select
a.*
from patient_list a
) as qry1
left join
(
Select
a.*
from PAC_7 a
limit 1 over (PARTITION BY a.member_id order by a.PAC_STY_ID desc)
) as qry2 on qry1.PATIENT_MEMBER_ID = qry2.member_id
;
--end region


--region This SQL retunrs the data in a format that is ready to be passed to the model

--create archive table
drop table if exists DATALAB_WORK_PRD.POC_patient_list_w_pac_variables_ARCHIVE;
create table DATALAB_WORK_PRD.POC_patient_list_w_pac_variables_ARCHIVE AS
SELECT * FROM DATALAB_WORK_PRD.POC_patient_list_w_pac_variables;

--create static table
drop table if exists DATALAB_WORK_PRD.POC_patient_list_w_pac_variables;
create table DATALAB_WORK_PRD.POC_patient_list_w_pac_variables as

select
*
,extract(year from CURRENT_FACILITY_ADMIT_DATE)||lpad(cast(extract(month from CURRENT_FACILITY_ADMIT_DATE) as varchar(2)),2,'0') as admit_date_folder
from patient_list_w_pac_variables
;
--end region



--region creates table of past DX 1,2, and 3
--create archive table
drop table if exists DATALAB_WORK_PRD.POC_dx_table_ARCHIVE;
create table DATALAB_WORK_PRD.POC_dx_table_ARCHIVE AS
SELECT * FROM DATALAB_WORK_PRD.POC_dx_table;
--create static table
drop table if exists DATALAB_WORK_PRD.POC_dx_table;
create table DATALAB_WORK_PRD.POC_dx_table as


select
a.MEMBER_ID
,a.PAC_STY_ID
,a.STAY_ADMIT_DATE
,a.STAY_DISCHARGE_DATE
,a.DX1
,a.DX2
,a.DX3

from MEDECON_PRD.PDM_CLAIMS a
inner join patient_list b on a.MEMBER_ID = b.PATIENT_MEMBER_ID
;
--end region

